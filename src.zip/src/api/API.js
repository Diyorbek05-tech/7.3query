import axios from "axios";

export const API_DUMMY = axios.create({
    baseURL: 'https://dummyjson.com',});